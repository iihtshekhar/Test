package com.skill.dto;

public enum Domain {
	Healthcare,
	Retail,
	Banking,
	Research,
	Logistics,
	Transport;
}

package com.skill.entitys;

public enum Domain {
	Healthcare,
	Retail,
	Banking,
	Research,
	Logistics,
	Transport;
}
